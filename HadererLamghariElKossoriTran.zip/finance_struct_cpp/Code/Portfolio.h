//
// Created by Julien on 29/05/2024.
//

#ifndef PROJET_PORTFOLIO_H
#define PROJET_PORTFOLIO_H


class Portfolio {
private:
    double amount;
public:
    Portfolio();
    double getAmount();
    void add(double d);
};


#endif //PROJET_PORTFOLIO_H
